USE internship_portal;

DESCRIBE User;
DESCRIBE Applicant;
DESCRIBE Internship;
DESCRIBE Application;
