CREATE DATABASE IF NOT EXISTS internship_portal; 
USE internship_portal;

-- USER 
-- userID (userRole,fName, lName, password, telNo, email)

CREATE TABLE IF NOT EXISTS User (
    userID      INT AUTO_INCREMENT, 
    userRole    ENUM ('applicant' , 'recruiter', 'admin' ) NOT NULL, 
    fName       VARCHAR(50) NOT NULL, 
    lName       VARCHAR(50) NOT NULL, 
    password    VARCHAR(255) NOT NULL, 
    telNo       VARCHAR(20),           -- fixed casing
    email       VARCHAR(255) NOT NULL, 
    CONSTRAINT PK_User PRIMARY KEY (userID), 
    CONSTRAINT UQ_User_email UNIQUE (email)
);

-- APPLICANT 
-- applicantID (fieldOfStudy, gpa, resumeURL, expectedGraduationYear, status, age)

CREATE TABLE IF NOT EXISTS Applicant( 
    applicantID             INT, 
    fieldOfStudy            VARCHAR(100), 
    gpa                     DECIMAL(3,2), 
    resumeURL               VARCHAR(255), 
    expectedGraduationYear  YEAR, 
    status                  VARCHAR(30), 
    age                     INT, 
    CONSTRAINT PK_Applicant PRIMARY KEY (applicantID),
    CONSTRAINT FK_Applicant_User
        FOREIGN KEY (applicantID) REFERENCES User(userID)
        ON DELETE CASCADE
);

-- COMPANY 
-- companyID (companyName, industry, websiteURL, address, description, noOfPostings)

CREATE TABLE IF NOT EXISTS Company ( 
    companyID       INT AUTO_INCREMENT, 
    companyName     VARCHAR(100) NOT NULL, 
    industry        VARCHAR(100), 
    websiteURL      VARCHAR(255), 
    address         VARCHAR(255), 
    description     TEXT, 
    noOfPostings    INT DEFAULT 0, 
    CONSTRAINT PK_Company PRIMARY KEY (companyID)
);

-- COMPANYADMIN
-- recruiterID (companyID) **recruiterID is also a User**
CREATE TABLE IF NOT EXISTS CompanyAdmin (
    recruiterID INT, 
    companyID   INT NOT NULL, 
    CONSTRAINT PK_CompanyAdmin PRIMARY KEY(recruiterID), 
    CONSTRAINT FK_CompanyAdmin_User
        FOREIGN KEY (recruiterID) REFERENCES User(userID)
        ON DELETE CASCADE, 
    CONSTRAINT FK_CompanyAdmin_Company
        FOREIGN KEY (companyID) REFERENCES Company(companyID)
        ON DELETE CASCADE
);

-- INTERNSHIP
-- internshipID (companyID, title, description, location, salary, startDate, endDate, requirements,
--              status, postDate)
-- workDuration is derived later via a VIEW

CREATE TABLE IF NOT EXISTS Internship ( 
    internshipID    INT AUTO_INCREMENT, 
    companyID       INT NOT NULL, 
    title           VARCHAR(150) NOT NULL, 
    description     TEXT,
    location        VARCHAR(100), 
    salary          DECIMAL(10,2),
    startDate       DATE,
    endDate         DATE, 
    requirements    TEXT, 
    status          VARCHAR(30), 
    postDate        DATE, 
    CONSTRAINT PK_Internship PRIMARY KEY (internshipID), 
    CONSTRAINT FK_Internship_Company
        FOREIGN KEY (companyID) REFERENCES Company(companyID)
        ON DELETE CASCADE
);

-- APPLICATION
-- applicationID (applicantID, internshipID, applicationDeadline, submissionDate) 

CREATE TABLE IF NOT EXISTS Application (
    applicationID       INT AUTO_INCREMENT, 
    applicantID         INT NOT NULL, 
    internshipID        INT NOT NULL, 
    applicationDeadline DATE,        -- fixed spelling
    submissionDate      DATE, 
    CONSTRAINT PK_Application PRIMARY KEY (applicationID),
    CONSTRAINT FK_Application_Applicant 
        FOREIGN KEY (applicantID) REFERENCES Applicant(applicantID)
        ON DELETE CASCADE,
    CONSTRAINT FK_Application_Internship
        FOREIGN KEY (internshipID) REFERENCES Internship (internshipID)
        ON DELETE CASCADE
);

-- APPLICATION STATUS HISTORY
-- historyID (applicationID, statusName, dateChanged, notes, outcome)
-- (no need to store internshipID again; we can get that through Application if needed)

CREATE TABLE IF NOT EXISTS ApplicationStatusHistory( 
    historyID       INT AUTO_INCREMENT, 
    applicationID   INT NOT NULL,        -- fixed column name
    statusName      VARCHAR(50) NOT NULL, 
    dateChanged     DATE,                -- could be DATETIME if you want time too
    notes           TEXT, 
    outcome         VARCHAR(50), 
    CONSTRAINT PK_ApplicationStatusHistory PRIMARY KEY (historyID),
    CONSTRAINT FK_ASH_Application
        FOREIGN KEY (applicationID) REFERENCES Application(applicationID)
        ON DELETE CASCADE
);

-- SKILL 
-- skillName (skillCategory, skillDescription)

CREATE TABLE IF NOT EXISTS Skill (
    skillName        VARCHAR(100), 
    skillCategory    VARCHAR(100),      -- fixed spelling only for clarity
    skillDescription TEXT, 
    CONSTRAINT PK_Skill PRIMARY KEY (skillName)
);

-- POSTING SKILL
-- (internshipID, skillName) -> importanceLVL

CREATE TABLE IF NOT EXISTS PostingSkill(
    internshipID  INT,
    skillName     VARCHAR(100), 
    importanceLVL TINYINT,
    CONSTRAINT PK_PostingSkill PRIMARY KEY (internshipID, skillName), 
    CONSTRAINT FK_PostingSkill_Internship
        FOREIGN KEY (internshipID) REFERENCES Internship(internshipID)
        ON DELETE CASCADE, 
    CONSTRAINT FK_PostingSkill_Skill 
        FOREIGN KEY (skillName) REFERENCES Skill (skillName)
        ON DELETE CASCADE
);
    
-- APPLICANT SKILL
-- (applicantID, skillName) -> proficiencyLVL

CREATE TABLE IF NOT EXISTS ApplicantSkill(
    applicantID    INT,
    skillName      VARCHAR(100), 
    proficiencyLVL TINYINT,
    CONSTRAINT PK_ApplicantSkill PRIMARY KEY (applicantID, skillName), 
    CONSTRAINT FK_ApplicantSkill_Applicant
        FOREIGN KEY (applicantID) REFERENCES Applicant(applicantID)
        ON DELETE CASCADE, 
    CONSTRAINT FK_ApplicantSkill_Skill 
        FOREIGN KEY (skillName) REFERENCES Skill (skillName)
        ON DELETE CASCADE
);

-- VIEW for derived workDuration (in days)

CREATE OR REPLACE VIEW InternshipWithDuration AS 
SELECT
    i.*, 
    DATEDIFF(i.endDate, i.startDate) AS workDurationDays
FROM Internship AS i;

    

    