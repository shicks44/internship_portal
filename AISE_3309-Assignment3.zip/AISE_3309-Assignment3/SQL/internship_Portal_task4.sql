USE internship_portal;

-- Simple INSERT into User (John Wick)
INSERT INTO User (userRole, fName, lName, password, telNo, email)
VALUES ('applicant', 'John', 'Wick', 'babaYaga123', '555-0101', 'john.wick@continental.com');

-- Multi-row INSERT into User
INSERT INTO User (userRole, fName, lName, password, telNo, email)
VALUES
  ('applicant', 'Sofia', 'Al-Azwar', 'desertDogs!', '555-0102', 'sofia@continental.com'),
  ('applicant', 'Charon', 'Lance', 'frontDesk#1', '555-0103', 'charon@continental.com'),
  ('recruiter', 'Winston', 'Scott', 'managerNYC', '555-0104', 'winston@continental.com'),
  ('recruiter', 'Shimazu', 'Koji', 'osakaBoss', '555-0105', 'koji.osaka@continental.com'),
  ('admin', 'Bowery', 'King', 'pigeonLord', '555-0106', 'bowery.king@underground.org');

-- INSERT...SELECT into Applicant
-- Turn all Users with role 'applicant' into Applicants
INSERT INTO Applicant (applicantID, fieldOfStudy, gpa, resumeURL, expectedGraduationYear, status, age)
SELECT
    u.userID, 
    'Assassin Studies' AS fieldOfStudy,
    3.90               AS gpa,
    CONCAT('https://resumes.example.com/', LOWER(u.fName), '.', LOWER(u.lName), '.pdf') AS resumeURL,
    2026               AS expectedGraduationYear,
    'active'           AS status,
    40                 AS age
FROM User AS u
WHERE u.userRole = 'applicant'
  AND u.userID NOT IN (SELECT applicantID FROM Applicant);

-- Check what we inserted 
SELECT * FROM User ORDER BY userID LIMIT 10;

SELECT ap.applicantID,
       u.fName,
       u.lName,
       ap.fieldOfStudy,
       ap.gpa
FROM Applicant AS ap
JOIN User AS u
  ON ap.applicantID = u.userID
ORDER BY ap.applicantID;
