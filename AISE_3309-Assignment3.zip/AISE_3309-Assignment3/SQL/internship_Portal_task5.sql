USE internship_portal;

--  Check counts BEFORE bulk inserts
SELECT COUNT(*) AS numUsers_before FROM User;
SELECT COUNT(*) AS numApplicants_before FROM Applicant;
SELECT COUNT(*) AS numApplications_before FROM Application;

-- Turn all applicant-Users into Applicants (many rows at once)
INSERT INTO Applicant (applicantID, fieldOfStudy, gpa, resumeURL, expectedGraduationYear, status, age)
SELECT
    u.userID,
    CASE 
        WHEN u.userID % 4 = 0 THEN 'Computer Science'
        WHEN u.userID % 4 = 1 THEN 'Mechanical Engineering'
        WHEN u.userID % 4 = 2 THEN 'Criminal Justice'
        ELSE 'Business'
    END AS fieldOfStudy,
    ROUND(2.5 + RAND() * 1.5, 2) AS gpa,
    CONCAT('https://resumes.example.com/', LOWER(u.fName), '.', LOWER(u.lName), '.pdf') AS resumeURL,
    2026 + (u.userID % 3) AS expectedGraduationYear,
    'active' AS status,
    20 + (u.userID % 15) AS age
FROM User AS u
WHERE u.userRole = 'applicant'
  AND u.userID NOT IN (SELECT applicantID FROM Applicant);

--  Make sure we have at least a few internships (in case you only have the three from Task 4)
INSERT INTO Internship (companyID, title, description, location, salary, startDate, endDate, requirements, status, postDate)
VALUES
  (1, 'Data Analyst Intern', 'Analyse High Table data.', 'New York', 70000.00,
   '2026-05-01', '2026-08-31', 'SQL, Python.', 'open', '2025-11-15'),
  (2, 'Security Systems Intern', 'Help secure Continental Osaka.', 'Osaka', 75000.00,
   '2026-05-15', '2026-09-15', 'Networks, Linux.', 'open', '2025-11-16'),
  (3, 'Threat Intelligence Intern', 'Track excommunicado activity.', 'Remote', 80000.00,
   '2026-06-01', '2026-12-01', 'OSINT, analytics.', 'open', '2025-11-17');

--  Create many Applications from Applicants to these internships
INSERT INTO Application (applicantID, internshipID, applicationDeadline, submissionDate)
SELECT
    ap.applicantID,
    CASE
        WHEN ap.applicantID % 3 = 0 THEN 4
        WHEN ap.applicantID % 3 = 1 THEN 5
        ELSE 6
    END AS internshipID,
    '2026-03-01' AS applicationDeadline,
    DATE('2025-11-01') + INTERVAL (ap.applicantID % 60) DAY AS submissionDate
FROM Applicant AS ap
LIMIT 4000;

--  Check counts AFTER bulk inserts
SELECT COUNT(*) AS numUsers_after FROM User;
SELECT COUNT(*) AS numApplicants_after FROM Applicant;
SELECT COUNT(*) AS numApplications_after FROM Application;

--  Show a few example rows for the report
SELECT * FROM User        ORDER BY userID       LIMIT 5;
SELECT * FROM Applicant   ORDER BY applicantID  LIMIT 5;
SELECT * FROM Application ORDER BY applicationID LIMIT 5;
