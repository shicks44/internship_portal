USE internship_portal;

-- list the first 20 applicant users, oredered by last then first name
SELECT userID, userRole, fName, lName, email
FROM User
Where userRole = 'applicant'
ORDER BY lName, fName
LIMIT 20; 

-- show name and gpa in decending order(4.0 first)
SELECT ap.applicantID, u.fName, u.lName, ap.fieldOfStudy, ap.gpa
FROM Applicant AS ap
JOIN USER AS u 
	ON ap.applicantID = u.userID
ORDER BY ap.gpa DESC, u.lName, u.fName
LIMIT 20; 

-- list the internships with company name and salary (highest -> lowest) 
SELECT i.internshipID, i.title, c.companyName, i.location, i.salary
FROM Internship as i
JOIN COMPANY as c
	on i.companyID = c.companyID
ORDER BY i.salary DESC, i.title;

-- count how many applicants per internship
SELECT i.internshipID, i.title, COUNT(a.applicationID) AS numApplications
FROM Internship as i
JOIN Application AS a
	ON i.internshipID = a.internshipID
GROUP BY i.internshipID, i.title
ORDER BY numApplications DESC, i.internshipID;

-- applicants who have a gpa above the average
SELECT ap.applicantID, u.fName, u.lName, ap.gpa 
FROM Applicant as ap 
JOIN User as u 
	on ap.applicantID = u.userID
where ap.gpa > (SELECT AVG(gpa) FROM Applicant) 
ORDER BY ap.gpa DESC, u.lName, u.fName 
LIMIT 50; 

-- using a view to show internships longer than 120 days (4 months) 
SELECT internshipID, title, workDurationDays
FROM InternshipWithDuration
WHERE workDurationDays > 120 
ORDER BY workDurationDays DESC;

-- list all applicants that have at least one application
SELECT DISTINCT ap.applicantID, u.fName, u.lName
FROM Applicant as ap
JOIN User AS u
	on ap.applicantID = u.userID
WHERE EXISTS ( 
	SELECT 1 
    FROM Application AS a
    WHERE a.applicantID = ap.applicantID
)
ORDER BY ap.applicantID 
limit 50; 
		