
USE internship_portal; 


-- insert initial status history for applications with no status history 

INSERT INTO ApplicationStatusHistory (applicationID, statusName, dateChanged, notes, outcome) 
SELECT a.applicationID, 
		'Submitted' as statusName, 
        CURDATE() AS dateChanged, 
        'Initial submission recorded!' as notes, 
        'pending' as outcome
FROM Application AS a
WHERE NOT EXISTS(
	SELECT 1 
    FROM ApplicationStatusHistory AS ash
    WHERE ash.applicationID = a.applicationID
);

SELECT * 
FROM ApplicationStatusHistory 
ORDER BY historyID
LIMIT 10; 

-- updates the status to accepted for applications from high GPA applicants (>= 3.8) 
UPDATE ApplicationStatusHistory as ash
JOIN Application as a 
	on ash.applicationID = a.applicationID 
JOIN Applicant as ap
	on a.applicantID = ap.applicantID 
SET ash.statusName = 'Accepted!', ash.outcome = 'accepted'
WHERE ap.gpa >= 3.8;

SELECT ash.historyID, ash.applicationID, ash.statusName, ash.outcome
FROM ApplicationStatusHistory AS ash
JOIN Application AS a
  ON ash.applicationID = a.applicationID
JOIN Applicant AS ap
  ON a.applicantID = ap.applicantID
WHERE ap.gpa >= 3.8
LIMIT 10;

-- check how many late submissions
SELECT COUNT(*) as numLateApplications
FROM Application 
Where submissionDate > applicationDeadline; 

-- delete the late apps 
DELETE FROM Application
WHERE applicationID IN (
    SELECT applicationID
    FROM ( 
		SELECT applicationID
        FROM Application
        WHERE submissionDate > applicationDeadline
    ) AS x
);

-- check totals after the delete 
SELECT COUNT(*) AS numApplications_after_delete
FROM Application; 

