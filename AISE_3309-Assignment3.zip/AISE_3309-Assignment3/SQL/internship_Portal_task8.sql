USE internship_portal; 

-- FIRST VIEW: Applicants with their names and basic info
CREATE OR REPLACE VIEW OpenInternships AS
SELECT internshipID, companyID, title, location, salary, startDate, endDate, status
FROM Internship
WHERE status = 'open';

-- Show some rows from OpenInternships
SELECT * 
FROM OpenInternships
LIMIT 10;

-- SECOND VIEW:  ApplicantGPAStats (non-updatable)
CREATE OR REPLACE VIEW ApplicantGPAStats AS
SELECT fieldOfStudy, AVG(gpa)  AS avgGpa, COUNT(*)  AS numApplicants
FROM Applicant
GROUP BY fieldOfStudy;

-- Show GPA statistics per field of study
SELECT * 
FROM ApplicantGPAStats;

-- list 10 open internships to select a ID 
SELECT * FROM OpenInternships LIMIT 10;

-- Test: OpenInternships is updatable - change salary through the view
UPDATE OpenInternships
SET salary = salary + 5000
WHERE internshipID = 5;   -- using the intershipID corresponding to 5

-- Check the base table to verify the change
SELECT internshipID, title, salary
FROM Internship
WHERE internshipID = 5;   -- internshipID = 5 again 

-- Test: ApplicantGPAStats is NOT updatable - this should fail
UPDATE ApplicantGPAStats
SET avgGpa = 4.0
WHERE fieldOfStudy = 'Computer Science';

