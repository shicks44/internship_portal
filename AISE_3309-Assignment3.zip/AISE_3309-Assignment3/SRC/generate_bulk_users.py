import random

# How many extra users to generate
NUM_EXTRA_USERS = 2500

# Name pools - includes some John Wick flavour
first_names = [
    "John", "Sofia", "Charon", "Winston", "Koji", "Akira",
    "Cassian", "Marcus", "Ares", "Zero", "Helen", "Killa",
    "Caine", "Sharon", "Santino", "Gianna", "Perkins"
]

last_names = [
    "Wick", "Al-Azwar", "Lance", "Scott", "Shimazu", "Yamada",
    "D'Antonio", "Tarasov", "Ruska", "Morales", "Kim", "Harrow",
    "Iosef", "Rossi", "Serrano", "Moreau", "Graves"
]

def make_email(fname, lname, idx):
    # basic deterministic email so we don't accidentally repeat
    clean_lname = lname.replace("'", "").replace(" ", "").lower()
    return f"{fname.lower()}.{clean_lname}{idx}@example.com"

# This script creates a SQL file in the same folder:
output_file = "bulk_users.sql"

with open(output_file, "w", encoding="utf-8") as f:
    f.write("-- Bulk user data for AISE 3309 Assignment 3 - Task 5\n")
    f.write("USE internship_portal;\n\n")

    for i in range(1, NUM_EXTRA_USERS + 1):
        fname = random.choice(first_names)
        lname = random.choice(last_names)
        role = random.choice(["applicant", "recruiter"])
        password = f"pw{random.randint(1000, 9999)}"
        tel = f"555-{1000 + i:04d}"
        email = make_email(fname, lname, i)

        sql = (
            "INSERT INTO User (userRole, fName, lName, password, telNo, email) "
            f"VALUES ('{role}', '{fname}', '{lname}', '{password}', '{tel}', '{email}');\n"
        )
        f.write(sql)

print(f"Done. Wrote {NUM_EXTRA_USERS} INSERT statements to {output_file}")

